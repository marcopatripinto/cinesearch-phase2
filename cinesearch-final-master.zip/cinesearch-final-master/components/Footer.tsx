import styles from "../styles/Footer.module.css";

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <p>© 2026 CineSearch. Built for CPAN 144 Group Project.</p>
    </footer>
  );
}