import Link from "next/link";
import { Movie } from "../data/movies";
import { useMovies } from "../context/MovieContext";
import styles from "../styles/MovieCard.module.css";

type Props = {
  movie: Movie;
};

export default function MovieCard({ movie }: Props) {
  const {
    addToFavorites,
    addToWatchLater,
    removeFromFavorites,
    removeFromWatchLater,
    isFavorite,
    isWatchLater,
  } = useMovies();

  const favoriteAdded = isFavorite(movie.id);
  const watchLaterAdded = isWatchLater(movie.id);

  return (
    <div className={styles.card}>
      <img src={movie.poster} alt={movie.title} className={styles.poster} />

      <div className={styles.content}>
        <h3>{movie.title}</h3>
        <p><strong>Year:</strong> {movie.year}</p>
        <p><strong>Genre:</strong> {movie.genre}</p>
        <p><strong>Rating:</strong> {movie.rating}</p>

        <div className={styles.actions}>
          <Link href={`/movies/${movie.id}`} className={styles.detailsButton}>
            View Details
          </Link>

          {favoriteAdded ? (
            <button
              onClick={() => removeFromFavorites(movie.id)}
              className={styles.removeButton}
            >
              Remove Favorite
            </button>
          ) : (
            <button
              onClick={() => addToFavorites(movie)}
              className={styles.favoriteButton}
            >
              Add Favorite
            </button>
          )}

          {watchLaterAdded ? (
            <button
              onClick={() => removeFromWatchLater(movie.id)}
              className={styles.removeButton}
            >
              Remove Watch Later
            </button>
          ) : (
            <button
              onClick={() => addToWatchLater(movie)}
              className={styles.watchButton}
            >
              Add Watch Later
            </button>
          )}
        </div>
      </div>
    </div>
  );
}