import Link from "next/link";
import { useRouter } from "next/router";
import styles from "../styles/Navbar.module.css";

export default function Navbar() {
  const router = useRouter();

  return (
    <nav className={styles.navbar}>
      <div className={styles.logo}>CineSearch</div>

      <div className={styles.links}>
        <Link
          href="/"
          className={router.pathname === "/" ? styles.active : ""}
        >
          Home
        </Link>

        <Link
          href="/favorites"
          className={router.pathname === "/favorites" ? styles.active : ""}
        >
          Favorites
        </Link>

        <Link
          href="/watch-later"
          className={router.pathname === "/watch-later" ? styles.active : ""}
        >
          Watch Later
        </Link>
      </div>
    </nav>
  );
}