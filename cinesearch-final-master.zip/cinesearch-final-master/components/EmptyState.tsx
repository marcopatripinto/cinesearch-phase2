import styles from "../styles/EmptyState.module.css";

type Props = {
  message: string;
};

export default function EmptyState({ message }: Props) {
  return (
    <div className={styles.emptyBox}>
      <p>{message}</p>
    </div>
  );
}