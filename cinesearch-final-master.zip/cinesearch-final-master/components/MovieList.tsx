import { Movie } from "../data/movies";
import MovieCard from "./MovieCard";
import styles from "../styles/MovieList.module.css";

type Props = {
  movies: Movie[];
};

export default function MovieList({ movies }: Props) {
  return (
    <div className={styles.grid}>
      {movies.map((movie) => (
        <MovieCard key={movie.id} movie={movie} />
      ))}
    </div>
  );
}