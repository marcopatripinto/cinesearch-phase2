import styles from "../styles/SearchBar.module.css";

type Props = {
  searchText: string;
  setSearchText: (value: string) => void;
};

export default function SearchBar({ searchText, setSearchText }: Props) {
  return (
    <div className={styles.searchBox}>
      <input
        type="text"
        placeholder="Search for a movie..."
        value={searchText}
        onChange={(e) => setSearchText(e.target.value)}
        className={styles.searchInput}
      />
    </div>
  );
}