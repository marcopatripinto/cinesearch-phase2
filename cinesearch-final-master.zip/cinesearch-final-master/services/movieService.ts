import movies, { Movie } from "../data/movies";

export const getAllMovies = (): Movie[] => {
  return movies;
};

export const getMovieById = (id: number): Movie | undefined => {
  return movies.find((movie) => movie.id === id);
};

export const searchMovies = (searchText: string): Movie[] => {
  return movies.filter((movie) =>
    movie.title.toLowerCase().includes(searchText.toLowerCase())
  );
};

// Placeholder for future API integration
export const fetchMoviesFromAPI = async () => {
  // In Phase 3, you can replace local data with a real API request here
  return Promise.resolve(movies);
};