import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { Movie } from "../data/movies";

type MovieContextType = {
    favorites: Movie[];
    watchLater: Movie[];
    addToFavorites: (movie: Movie) => void;
    removeFromFavorites: (id: number) => void;
    addToWatchLater: (movie: Movie) => void;
    removeFromWatchLater: (id: number) => void;
    isFavorite: (id: number) => boolean;
    isWatchLater: (id: number) => boolean;
};

const MovieContext = createContext<MovieContextType | undefined>(undefined);

type Props = {
    children: ReactNode;
};

export const MovieProvider = ({ children }: Props) => {
    const [favorites, setFavorites] = useState<Movie[]>([]);
    const [watchLater, setWatchLater] = useState<Movie[]>([]);

    useEffect(() => {
        const savedFavorites = localStorage.getItem("favorites");
        const savedWatchLater = localStorage.getItem("watchLater");

        if (savedFavorites) {
            setFavorites(JSON.parse(savedFavorites));
        }

        if (savedWatchLater) {
            setWatchLater(JSON.parse(savedWatchLater));
        }
    }, []);

    useEffect(() => {
        localStorage.setItem("favorites", JSON.stringify(favorites));
    }, [favorites]);

    useEffect(() => {
        localStorage.setItem("watchLater", JSON.stringify(watchLater));
    }, [watchLater]);

    const addToFavorites = (movie: Movie) => {
        if (!favorites.find((item) => item.id === movie.id)) {
            setFavorites([...favorites, movie]);
        }
    };

    const removeFromFavorites = (id: number) => {
        setFavorites(favorites.filter((movie) => movie.id !== id));
    };

    const addToWatchLater = (movie: Movie) => {
        if (!watchLater.find((item) => item.id === movie.id)) {
            setWatchLater([...watchLater, movie]);
        }
    };

    const removeFromWatchLater = (id: number) => {
        setWatchLater(watchLater.filter((movie) => movie.id !== id));
    };

    const isFavorite = (id: number) => {
        return favorites.some((movie) => movie.id === id);
    };

    const isWatchLater = (id: number) => {
        return watchLater.some((movie) => movie.id === id);
    };

    return (
        <MovieContext.Provider
            value={{
                favorites,
                watchLater,
                addToFavorites,
                removeFromFavorites,
                addToWatchLater,
                removeFromWatchLater,
                isFavorite,
                isWatchLater,
            }}
    >
            {children}
        </MovieContext.Provider>
    );
};

export const useMovies = () => {
    const context = useContext(MovieContext);

    if (!context) {
        throw new Error("useMovies must be used inside MovieProvider");
    }

    return context;
};