import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import MovieList from "../components/MovieList";
import EmptyState from "../components/EmptyState";
import { useMovies } from "../context/MovieContext";
import styles from "../styles/Page.module.css";

export default function WatchLaterPage() {
  const { watchLater } = useMovies();

  return (
    <div className={styles.page}>
      <Navbar />

      <main className={styles.main}>
        <h1>Watch Later</h1>
        <p>Movies you want to watch in the future will appear here.</p>

        {watchLater.length > 0 ? (
          <MovieList movies={watchLater} />
        ) : (
          <EmptyState message="No movies added to Watch Later yet." />
        )}
      </main>

      <Footer />
    </div>
  );
}