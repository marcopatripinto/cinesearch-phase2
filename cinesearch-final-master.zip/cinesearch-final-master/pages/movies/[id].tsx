import { useRouter } from "next/router";
import Link from "next/link";
import Navbar from "../../components/Navbar";
import Footer from "../../components/Footer";
import { getMovieById } from "../../services/movieService";
import { useMovies } from "../../context/MovieContext";
import styles from "../../styles/MovieDetails.module.css";

export default function MovieDetailsPage() {
  const router = useRouter();
  const { id } = router.query;

  const movieId = Number(id);
  const movie = getMovieById(movieId);

  const {
    addToFavorites,
    addToWatchLater,
    removeFromFavorites,
    removeFromWatchLater,
    isFavorite,
    isWatchLater,
  } = useMovies();

  if (!movie) {
    return (
      <div className={styles.page}>
        <Navbar />
        <main className={styles.main}>
          <h1>Movie not found</h1>
          <Link href="/" className={styles.backButton}>
            Back to Home
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  const favoriteAdded = isFavorite(movie.id);
  const watchLaterAdded = isWatchLater(movie.id);

  return (
    <div className={styles.page}>
      <Navbar />

      <main className={styles.main}>
        <div className={styles.card}>
          <img src={movie.poster} alt={movie.title} className={styles.poster} />

          <div className={styles.info}>
            <h1>{movie.title}</h1>
            <p><strong>Year:</strong> {movie.year}</p>
            <p><strong>Genre:</strong> {movie.genre}</p>
            <p><strong>Rating:</strong> {movie.rating}</p>
            <p><strong>Director:</strong> {movie.director}</p>
            <p><strong>Description:</strong> {movie.description}</p>

            <div className={styles.actions}>
              {favoriteAdded ? (
                <button
                  onClick={() => removeFromFavorites(movie.id)}
                  className={styles.removeButton}
                >
                  Remove Favorite
                </button>
              ) : (
                <button
                  onClick={() => addToFavorites(movie)}
                  className={styles.favoriteButton}
                >
                  Add Favorite
                </button>
              )}

              {watchLaterAdded ? (
                <button
                  onClick={() => removeFromWatchLater(movie.id)}
                  className={styles.removeButton}
                >
                  Remove Watch Later
                </button>
              ) : (
                <button
                  onClick={() => addToWatchLater(movie)}
                  className={styles.watchButton}
                >
                  Add Watch Later
                </button>
              )}

              <Link href="/" className={styles.backButton}>
                Back to Home
              </Link>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}