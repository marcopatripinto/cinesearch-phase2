import type { AppProps } from "next/app";
import { MovieProvider } from "../context/MovieContext";
import "../styles/globals.css";

export default function App({ Component, pageProps }: AppProps) {
  return (
    <MovieProvider>
      <Component {...pageProps} />
    </MovieProvider>
  );
}