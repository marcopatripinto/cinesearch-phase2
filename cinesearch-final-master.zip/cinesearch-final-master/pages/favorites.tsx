import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import MovieList from "../components/MovieList";
import EmptyState from "../components/EmptyState";
import { useMovies } from "../context/MovieContext";
import styles from "../styles/Page.module.css";

export default function FavoritesPage() {
  const { favorites } = useMovies();

  return (
    <div className={styles.page}>
      <Navbar />

      <main className={styles.main}>
        <h1>Favorites</h1>
        <p>Your favorite movies are saved here.</p>

        {favorites.length > 0 ? (
          <MovieList movies={favorites} />
        ) : (
          <EmptyState message="No favorite movies added yet." />
        )}
      </main>

      <Footer />
    </div>
  );
}