import { useState } from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import SearchBar from "../components/SearchBar";
import MovieList from "../components/MovieList";
import SummaryCard from "../components/SummaryCard";
import { getAllMovies, searchMovies } from "../services/movieService";
import { useMovies } from "../context/MovieContext";
import styles from "../styles/Home.module.css";

export default function Home() {
  const [searchText, setSearchText] = useState("");
  const { favorites, watchLater } = useMovies();

  const allMovies = getAllMovies();
  const filteredMovies = searchText ? searchMovies(searchText) : allMovies;

  return (
    <div className={styles.page}>
      <Navbar />

      <main className={styles.main}>
        <section className={styles.hero}>
          <h1>CineSearch</h1>
          <p>Search movies, save favorites, and plan what to watch later.</p>
        </section>

        <section className={styles.summarySection}>
          <SummaryCard title="Total Movies" value={allMovies.length} />
          <SummaryCard title="Favorites" value={favorites.length} />
          <SummaryCard title="Watch Later" value={watchLater.length} />
        </section>

        <SearchBar searchText={searchText} setSearchText={setSearchText} />

        <MovieList movies={filteredMovies} />
      </main>

      <Footer />
    </div>
  );
}