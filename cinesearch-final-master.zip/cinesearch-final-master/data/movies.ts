export type Movie = {
  id: number;
  title: string;
  year: string;
  poster: string;
  genre: string;
  rating: string;
  description: string;
  director: string;
};
const movies: Movie[] = [
  {
    id: 1,
    title: "Inception",
    year: "2010",
    poster: "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_FMjpg_UX700_.jpg",
    genre: "Sci-Fi",
    rating: "8.8",
    description: "A thief enters dreams to steal secrets and is given a final mission.",
    director: "Christopher Nolan",
  },
  {
    id: 2,
    title: "Interstellar",
    year: "2014",
    poster: "https://m.media-amazon.com/images/M/MV5BYzdjMDAxZGItMjI2My00ODA1LTlkNzItOWFjMDU5ZDJlYWY3XkEyXkFqcGc@._V1_FMjpg_UY3600_.jpg",
    genre: "Adventure",
    rating: "8.6",
    description: "A team travels through space in search of a new home for humanity.",
    director: "Christopher Nolan",
  },
  {
    id: 3,
    title: "The Dark Knight",
    year: "2008",
    poster: "https://m.media-amazon.com/images/M/MV5BN2NmN2VhMTQtMDNiOS00NDlhLTliMjgtODE2ZTY0ODQyNDRhXkEyXkFqcGc@._V1_FMjpg_UY3156_.jpg",
    genre: "Action",
    rating: "9.0",
    description: "Batman faces the Joker in Gotham City.",
    director: "Christopher Nolan",
  },
  {
    id: 4,
    title: "The Matrix",
    year: "1999",
    poster: "https://m.media-amazon.com/images/M/MV5BMDEzMmQwZjctZWU2My00MWNlLWE0NjItMDJlYTRlNGJiZjcyXkEyXkFqcGc@._V1_FMjpg_UY2902_.jpg",
    genre: "Sci-Fi",
    rating: "8.7",
    description: "A hacker learns the truth about reality and joins the resistance.",
    director: "The Wachowskis",
  },
];

export default movies;